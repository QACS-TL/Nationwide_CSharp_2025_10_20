﻿namespace LoopsAndCollections
{
    internal class Program
    {
        static void Main(string[] args)
        {
            LoopsCollections.ArrayInitialisation(); // Page 4
            LoopsCollections.LoopingThroughArrays();  // Page 6
            LoopsCollections.ForEachLoops(); // Page 7
            LoopsCollections.ForLoops(); // Pages 8 to 10
            LoopsCollections.WhileLoops(); // Page 11
            LoopsCollections.DoLoops(); // Page 12
            //Collections
            LoopsCollections.GenericLists(); // Page 15
            LoopsCollections.Dictionaries(); // Page 16
            LoopsCollections.StrongTyping(); // Page 17
            LoopsCollections.IndexerAccessOperator(); // Page 20


            // ************* APPENDIX **************


            LoopsCollections.ForLoopsIteratorInitialiserNestedGoto(); // Pages 24 to 27
            LoopsCollections.WhileLoopExamples(); // Page 28
            LoopsCollections.DoLoopExamples(); // Page 29
            LoopsCollections.ListOfTExamples(); // Page 30
            LoopsCollections.DictionaryIteration(); // Pages 31 and 32
            LoopsCollections.IndexFromEndAndRangeOperator(); // Page 33

        }
    }
}