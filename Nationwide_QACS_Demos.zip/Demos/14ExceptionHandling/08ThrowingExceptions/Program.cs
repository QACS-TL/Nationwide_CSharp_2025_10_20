﻿using System;

namespace _08ThrowingExceptions
{
    class Program
    {
        static void Main(string[] args)
        {
            string invoiceNumber = "123456";
            DateTime invoiceDate = DateTime.Now.Date;
            decimal grossAmount = 100.00m;
            string customerName = "G. Garvey";
            string description = "3 Packets of Crisps";
            DateTime paymentDueDate = invoiceDate.AddDays(28);

            Invoice validinvoice = new Invoice(invoiceNumber,
                invoiceDate,
                grossAmount,
                customerName,
                description,
                paymentDueDate
            );


            Console.WriteLine($"Valid Invoice:\n    Invoice Date: {validinvoice.InvoiceDate:D}, PaymentDueDate: {validinvoice.PaymentDueDate:D}" +
                                $"\n    Gross: {validinvoice.GrossAmount:C}, Net: {validinvoice.NetAmount:C}, VAT: {validinvoice.VATAmount:C}\n\n");

            //Future date
            try
            {
                DateTime futureDate = DateTime.Now.Date.AddYears(1);
                Invoice invalidinvoice = new Invoice(invoiceNumber,
                    futureDate,
                    grossAmount,
                    customerName,
                    description,
                    paymentDueDate
                );
                //Should not be reached
                Console.WriteLine($"invalidinvoice - Invoice Date: {validinvoice.InvoiceDate}, PaymentDueDate: {validinvoice.PaymentDueDate}");

            }
            catch (IllegalInvoiceDateException ex)
            {
                Console.WriteLine(ex.Message);
            }

            //Payment Due Date Earlier than Invoice Date
            try
            {
                DateTime earlyPaymentDueDate = DateTime.Now.Date.AddYears(-1);
                Invoice invalidinvoice = new Invoice(invoiceNumber,
                    invoiceDate,
                    grossAmount,
                    customerName,
                    description,
                    earlyPaymentDueDate
                );
                //Should not be reached
                Console.WriteLine($"invalidinvoice - Invoice Date: {validinvoice.InvoiceDate:D}, PaymentDueDate: {validinvoice.PaymentDueDate:D}");

            }
            catch (IllegalInvoiceDateException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
