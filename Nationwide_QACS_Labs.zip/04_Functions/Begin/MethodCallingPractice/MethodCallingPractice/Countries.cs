﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MethodCallingPractice {
  public class Countries {

    public static int Finland() {
      return 1000;
    }

    public static double Chile() {
      return 400;
    }

    public static string Russia() {
      return "Nineteen Twenty-Three";
    }

    public static int Mongolia() {
      return 1211;
    }

    public static string Zimbabwe() {
      return "$Z2,621,984,228";

    }

  }
}
