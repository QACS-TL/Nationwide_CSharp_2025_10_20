﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Finance;

namespace ClientExe {
  class Program {
    static void Main(string[] args) {
      
      Account ac1, ac2;
      ac1 = new Account("Fred", 100);
      ac2 = new Account("Susy", 0);
      ac1.Deposit(100);
      ac2.Withdraw(300);
      Account.Transfer(ac1, ac2, 50);
      Console.WriteLine(ac1.GetDetails());
      Console.WriteLine(ac2.GetDetails());


      // Challenge 1
      Console.WriteLine("\nChallenge 1");
      List<Account> accs = new List<Account> { ac1, ac2 };
      ProcessAccounts(accs);
      Console.WriteLine($"{ac1.holder}\t{ac1.balance}" );
      Console.WriteLine($"{ac2.holder}\t{ac2.balance}");
      Console.WriteLine();
      
      // Challenge 2
      Console.WriteLine("\nChallenge 2");
      List<string> names = new List<string> { "Ann", "Anne", "Annie", "Anneka", "Annabel"};
      List<Account> studentAccs = new List<Account>();
      Random r = new Random();
      for (int i = 0; i < names.Count; i++)
      {
        studentAccs.Add(new Account(names[i], r.Next(100)));
      }
      foreach (Account a in studentAccs)
      {
        Console.WriteLine(a.GetDetails());
      }
      for (int i = 0; i < studentAccs.Count; i++)
      {
        if (i < studentAccs.Count - 1)
        {
          Account.Transfer(studentAccs[i], studentAccs[i + 1],studentAccs[i].holder.Length);
        }
        else
        {
          Account.Transfer(studentAccs[i], studentAccs[0], studentAccs[i].holder.Length);
        }
      }
      foreach (Account a in studentAccs)
      {
        Console.WriteLine(a.GetDetails());
      }
    }

    private static void ProcessAccounts(List<Account> accs) {
      foreach (Account a in accs)
      {
        a.Deposit(10);
      }
    }
  }
}
