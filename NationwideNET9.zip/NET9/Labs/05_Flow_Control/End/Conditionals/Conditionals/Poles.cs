﻿namespace Conditionals

{



    public enum Pole //An enum is a data type in its own right.

    {

        North,

        South

    }

}