﻿namespace CoffeeShop
{
    public class Drink
    {
        public string Name { get; }
        public decimal Price { get; }

        public Drink(string name, decimal price)
        {
            Name = name;
            Price = price;
        }
    }
}
