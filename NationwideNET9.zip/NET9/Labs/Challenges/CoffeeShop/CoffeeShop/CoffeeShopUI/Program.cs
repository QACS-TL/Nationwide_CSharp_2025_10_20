﻿// Setup menu
using CoffeeShop;

var menu = new Dictionary<string, Drink>(StringComparer.OrdinalIgnoreCase)
            {
                { "Espresso", new Drink("Espresso", 2.50m) },
                { "Latte", new Drink("Latte", 3.50m) },
                { "Cappuccino", new Drink("Cappuccino", 3.00m) }
            };

var order = new Order();

Console.WriteLine("Welcome to ChatGPT Coffee Shop!");
Console.WriteLine("Menu:");
foreach (var item in menu.Values)
{
    Console.WriteLine($"- {item.Name} (${item.Price})");
}
Console.WriteLine("\nType the name of the drink to order, or \"done\" to finish:\n");

while (true)
{
    Console.Write("> ");
    var input = Console.ReadLine();

    if (input.Equals("done", StringComparison.OrdinalIgnoreCase))
    {
        break;
    }

    if (menu.ContainsKey(input))
    {
        order.AddDrink(menu[input]);
        Console.WriteLine($"{input} added to your order.");
    }
    else
    {
        Console.WriteLine("Drink not found, please try again.");
    }
}

Console.WriteLine($"\nYour total is: ${order.GetTotal():0.00}");
Console.WriteLine("Thank you for your order!");
