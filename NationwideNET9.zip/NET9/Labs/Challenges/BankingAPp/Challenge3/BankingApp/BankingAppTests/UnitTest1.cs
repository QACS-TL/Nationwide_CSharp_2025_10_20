using BankingApp;
using System.Text;
using Moq;

namespace BankingAppTests
{
    public class AccountNumberValidationTests
    {
        StringBuilder _ConsoleOutput;
        Mock<TextReader> _ConsoleInput;


        public void Setup()
        {
            _ConsoleOutput = new StringBuilder();
            var consoleOutputWriter = new StringWriter(_ConsoleOutput);
            _ConsoleInput = new Mock<TextReader>();
            Console.SetOut(consoleOutputWriter);
            Console.SetIn(_ConsoleInput.Object);
        }

        private string[] RunMenuAndGetConsoleOutput()
        {
            //Program.Main(default);
            Program.Menu();
            return _ConsoleOutput.ToString().Split("\r\n");
        }

        private MockSequence SetupUserResponses(params string[] userResponses)
        {
            var sequence = new MockSequence();
            foreach (var response in userResponses)
            {
                _ConsoleInput.InSequence(sequence).Setup(x => x.ReadLine()).Returns(response);
            }
            return sequence;
        }


        [Fact]
        public void TestMenu()
        {
            Setup();
            //Arrange
            SetupUserResponses("1");
            var expectedPrompt = "Welcome to QA Banking\n"
                + "Enter:\n"
                + " 1 for Balance\n"
                + " 2 to Credit\n"
                + " 3 to Debit\n"
                + "or 'Q' to quit";

            var outputLines = RunMenuAndGetConsoleOutput();

            Assert.Equal(expectedPrompt, outputLines[0]);
            //string accountNumber = "111111";
            //decimal? expectedBalance = 50.01M;
            //Dictionary<string, decimal> accounts = Program.CreateAccounts();

            ////Act
            //decimal? actualBalance = Program.LogIn(accounts);

            ////Assert
            //Assert.Equal(expectedBalance, actualBalance);
        }

        //[Fact]
        //public void TestLoginWithValidAccountNumberEnteredASFirstAttempt()
        //{
        //    //Arrange
        //    string accountNumber = "111111";
        //    decimal? expectedBalance = 50.01M;
        //    Dictionary<string, decimal> accounts = Program.CreateAccounts();

        //    //Act
        //    decimal? actualBalance = Program.LogIn(accounts);

        //    //Assert
        //    Assert.Equal(expectedBalance, actualBalance);
        //}
    }
}