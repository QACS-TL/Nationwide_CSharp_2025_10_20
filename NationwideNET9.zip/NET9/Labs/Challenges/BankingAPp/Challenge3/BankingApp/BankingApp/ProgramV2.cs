﻿
using System.ComponentModel.Design;
using System.Runtime.CompilerServices;

[assembly:InternalsVisibleTo("BankingAppTests")]
namespace BankingApp
{
    public class Program
    {

        public static void Main()
        {
            Dictionary<string, decimal> accounts = CreateAccounts();
            decimal? nullableBalance = LogIn(accounts);
            if (nullableBalance == null)
            {
                Console.WriteLine("Invalid Credentials. Program terminating");
                return;
            }

            decimal balance = (decimal)nullableBalance;

            //Get Balance
            Console.WriteLine(GetFormattedBalance(balance));
            while(true) { 
            string selection = Menu();
                switch (selection)
                {
                    case "1":
                        Console.WriteLine(GetFormattedBalance(balance));
                        break;
                    //Credit
                    case "2":
                        decimal amount = Prompt("credit");
                        if (amount > 0.00M)
                        {
                            balance = Credit(balance, amount);
                            Console.WriteLine(GetFormattedBalance(balance));
                        }
                        break;

                    //Debit
                    case "3":
                        amount = Prompt("debit");
                        if (amount > 0.00M)
                        {
                            balance = Debit(balance, amount);
                            Console.WriteLine(GetFormattedBalance(balance));
                        }
                        break;
                    case "q":
                    case "Q":
                        Console.WriteLine("Program Terminated");
                        return;
                    default:
                        Console.WriteLine("Invalid choice");
                        break;
                }
            }

        }

        public static string Menu()
        {
            string menuText =
                "Welcome to QA Banking\n"
                + "Enter:\n"
                + " 1 for Balance\n"
                + " 2 to Credit\n"
                + " 3 to Debit\n"
                + "or 'Q' to quit";
            Console.WriteLine(menuText);
            string selection = Console.ReadLine();
            return selection;
        }

        public static decimal Prompt(string promptText)
        {
            string message = $"Please enter the amount you would like to {promptText} or 'c' to cancel";
            decimal amount;
            bool canConvert;
            do
            {
                Console.WriteLine(message);
                string amountAsString = Console.ReadLine();
                if (amountAsString.ToLower() == "c")
                {
                    // amounts can't be negative so doing this will tell the client the client to cancel the operation
                    return -1M;
                }
                canConvert = decimal.TryParse(amountAsString, out amount);
                message = "Amounts must be numeric and positive or 'c' to cancel ";
            } while (!canConvert || amount < 0) ;
            return amount;
        }

        public static string GetFormattedBalance(decimal balance)
        {
            return $"Your current balance is {balance:C2}";
        }

        public static decimal Credit(decimal balance, decimal value)
        {
            return balance += value;
        }

        public static decimal Debit(decimal balance, decimal value)
        {
            return balance -= value;
        }

        public static decimal? LogIn(Dictionary<string, decimal> accounts)
        {
            string message = "Please enter your account number";
            string accountNumber;
            //see if account number is valid
            int count = 1;
            do
            {
                Console.WriteLine(message);
                accountNumber = Console.ReadLine();
                message = "Invalid Account number. Please try entering your account number again:";
                count++;
            } while (!accounts.ContainsKey(accountNumber) && count < 3);
            
            if (!accounts.ContainsKey(accountNumber))
            {
                return null;
            }
            return accounts[accountNumber];
        }

        public static Dictionary<string,  decimal> CreateAccounts()
        {
            //Tuple structure: accountNumber, PIN, Balance
            Dictionary<string, decimal> accounts = new Dictionary<string, decimal>();
            accounts.Add("111111", 50.01M);
            accounts.Add("222222", 0.00M);
            accounts.Add("333333", 20.50M);
            accounts.Add("444444", 250.00M);
            return accounts;
        }
     
    }
}
