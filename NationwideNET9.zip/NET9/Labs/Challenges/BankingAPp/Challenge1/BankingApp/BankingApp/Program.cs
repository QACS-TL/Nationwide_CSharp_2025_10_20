﻿
namespace BankingApp
{
    public class Program
    {

        public static void Main()
        {
            decimal balance = 0.00M;
            //Get Balance
            Console.WriteLine(GetFormattedBalance(balance));

            //Credit
            //GetBalance
            decimal amount = Prompt("credit");
            balance = Credit(balance, amount);
            Console.WriteLine(GetFormattedBalance(balance));

            //Debit
            //GetBalance
            amount = Prompt("debit");
            balance = Debit(balance, amount);
            Console.WriteLine(GetFormattedBalance(balance));


            //Credit
            //GetBalance
            amount = Prompt("credit");
            balance = Credit(balance, amount);
            Console.WriteLine(GetFormattedBalance(balance));

        }

        public static decimal Prompt(string promptText)
        {
            Console.WriteLine($"Please enter the amount you would like to {promptText}");
            string amount = Console.ReadLine();
            return decimal.Parse( amount );
        }

        public static string GetFormattedBalance(decimal balance)
        {
            return $"Your current balance is {balance:C2}";
        }

        public static decimal Credit(decimal balance, decimal value)
        {
            return balance += value;
        }

        public static decimal Debit(decimal balance, decimal value)
        {
            return balance -= value;
        }
    }
}
