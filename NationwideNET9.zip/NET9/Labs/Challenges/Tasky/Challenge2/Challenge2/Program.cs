﻿// Program.cs (Console App) — Challenge 2
using System;

string NormalizePriority(string input)
{
    input = (input ?? "").Trim().ToLowerInvariant();
    return input switch
    {
        "low" => "Low",
        "l" => "Low",
        "medium" => "Medium",
        "m" => "Medium",
        "high" => "High",
        "h" => "High",
        _ => ""
    };
}

string BuildPriorityMessage(string description, DateTime deadline, string priority)
{
    // priority is expected to be Low/Medium/High
    return priority switch
    {
        "High" => $"ALERT: High-priority task: {description} by {deadline:ddd dd MMM yyyy}",
        "Medium" => $"Medium-priority task: {description} by {deadline:ddd dd MMM yyyy}",
        "Low" => $"Low-priority task: {description} by {deadline:ddd dd MMM yyyy}",
        _ => $"Unknown priority for task: {description} by {deadline:ddd dd MMM yyyy}"
    };
}

string ReadNonEmpty(string prompt)
{
    while (true)
    {
        Console.Write(prompt);
        var input = Console.ReadLine() ?? "";
        if (!string.IsNullOrWhiteSpace(input))
            return input.Trim();
        Console.WriteLine($"Please enter a non-empty value for {prompt}.");
    }
}

// --- Main flow ---
Console.WriteLine("== Task Prioritizer ==");
var description = ReadNonEmpty("Description: ");
var deadline = DateTime.Parse(ReadNonEmpty("Deadline: "));
string priority = ReadNonEmpty("Priority (Low/Medium/High): ");
priority = NormalizePriority(priority);

var message = BuildPriorityMessage(description, deadline, priority);
Console.WriteLine(message);
