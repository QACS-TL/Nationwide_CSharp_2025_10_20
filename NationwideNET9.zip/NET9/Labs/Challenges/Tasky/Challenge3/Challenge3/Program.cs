﻿// Program.cs (Console App) — Challenge 2
using System;
using System.Collections.Generic;

List<string> tasks = new();

void ShowMenu()
{
    Console.WriteLine();
    Console.WriteLine("== To-Do List Manager ==");
    Console.WriteLine("[1] Add task");
    Console.WriteLine("[2] View tasks");
    Console.WriteLine("[3] Remove task");
    Console.WriteLine("[4] Clear all");
    Console.WriteLine("[0] Exit");
    Console.Write("Select: ");
}

void AddTask()
{
    string description;
    DateTime deadline;
    string priority;

    // Loop until a valid description is provided
    while (true)
    {
        description = ReadNonEmpty("Description: ");
        if (!string.IsNullOrWhiteSpace(description))
            break;
        Console.WriteLine("Description cannot be empty.");
    }

    // Loop until a valid deadline is provided (date, not in the past)
    while (true)
    {
        var input = ReadNonEmpty("Deadline (e.g., 31/12/2026): ");
        if (DateTime.TryParse(input, out deadline))
        {
            if (deadline >= DateTime.Today)
                break;
            Console.WriteLine("Deadline cannot be in the past.");
        }
        else
        {
            Console.WriteLine("Please enter a valid date.");
        }
    }

    // Loop until a valid priority is provided (Low/Medium/High)
    while (true)
    {
        var input = ReadNonEmpty("Priority (Low/Medium/High): ");
        priority = NormalizePriority(input);
        if (!string.IsNullOrEmpty(priority))
            break;
        Console.WriteLine("Priority must be Low, Medium, or High.");
    }

    // Build final task message
    var message = BuildPriorityMessage(description, deadline, priority);

    if (tasks.Contains(message, StringComparer.OrdinalIgnoreCase))
    {
        Console.WriteLine("That task already exists.");
        return;
    }

    tasks.Add(message);
    Console.WriteLine("Added.");
}


void ViewTasks()
{
    if (tasks.Count == 0)
    {
        Console.WriteLine("(No tasks)");
        return;
    }
    for (int i = 0; i < tasks.Count; i++)
        Console.WriteLine($"{i + 1}. {tasks[i]}");
}

void RemoveTask()
{
    if (tasks.Count == 0)
    {
        Console.WriteLine("No tasks to remove.");
        return;
    }
    ViewTasks();
    Console.Write("Remove which number? ");
    if (int.TryParse(Console.ReadLine(), out var n) && n >= 1 && n <= tasks.Count)
    {
        tasks.RemoveAt(n - 1);
        Console.WriteLine("Removed.");
    }
    else
    {
        Console.WriteLine("Invalid selection.");
    }
}

string NormalizePriority(string input)
{
    input = (input ?? "").Trim().ToLowerInvariant();
    return input switch
    {
        "low" => "Low",
        "l" => "Low",
        "medium" => "Medium",
        "m" => "Medium",
        "high" => "High",
        "h" => "High",
        _ => ""
    };
}

string BuildPriorityMessage(string description, DateTime deadline, string priority)
{
    // priority is expected to be Low/Medium/High
    return priority switch
    {
        "High" => $"ALERT: High-priority task: {description} by {deadline:ddd dd MMM yyyy}",
        "Medium" => $"Medium-priority task: {description} by {deadline:ddd dd MMM yyyy}",
        "Low" => $"Low-priority task: {description} by {deadline:ddd dd MMM yyyy}",
        _ => $"Unknown priority for task: {description} by {deadline:ddd dd MMM yyyy}"
    };
}

string ReadNonEmpty(string prompt)
{
    while (true)
    {
        Console.Write(prompt);
        var input = Console.ReadLine() ?? "";
        if (!string.IsNullOrWhiteSpace(input))
            return input.Trim();
        Console.WriteLine($"Please enter a non-empty value for {prompt}.");
    }
}

// --- Main flow ---
Console.WriteLine("== Task Prioritizer ==");
while (true)
{
    ShowMenu();
    var choice = Console.ReadLine();
    Console.WriteLine();

    switch (choice)
    {
        case "1": AddTask(); break;
        case "2": ViewTasks(); break;
        case "3": RemoveTask(); break;
        case "4":
            tasks.Clear();
            Console.WriteLine("All tasks cleared.");
            break;
        case "0": Console.WriteLine("Goodbye!"); return;
        default: Console.WriteLine("Unknown option."); break;
    }
}
