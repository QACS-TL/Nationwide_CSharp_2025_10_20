﻿using Challenge5Tasky;
using System.Reflection;
using Xunit;

namespace Challenge5Tests
{
    public class TaskItemTests
    {
        public TaskItemTests()
        {
            typeof(TaskItem)
                .GetField("_nextId", BindingFlags.Static | BindingFlags.NonPublic)
                .SetValue(null, 1);
        }

        [Fact]
        public void MarkComplete_SetsIsCompletedTrue()
        {
            var t = new TaskItem("Buy milk", DateTime.Now, Priority.High);
            t.MarkComplete();
            Assert.True(t.IsCompleted);
        }

        [Fact]
        public void Creating_WithEmptyDescription_Throws()
        {
            Assert.Throws<ArgumentException>(() => new TaskItem("", DateTime.Now, Priority.Low));
        }

        [Fact]
        public void Edit_UpdatesDescriptionAndPriority()
        {
            var t = new TaskItem("Old", DateTime.Now, Priority.Low);
            t.EditTask("New", null, Priority.High);
            Assert.Equal("New", t.Description);
            Assert.Equal(Priority.High, t.Priority);
        }

        [Fact]
        public void ToString_IncludesPriorityAndStatus()
        {
            var t = new TaskItem("Task", DateTime.Now, Priority.Medium);
            var str = t.ToString();
            Assert.Contains("Medium-priority", str);
            Assert.Contains("Not Completed", str);
            t.MarkComplete();
            str = t.ToString();
            Assert.Contains("Completed", str);
        }

        [Fact]
        public void Id_IsUniqueAndIncrementing()
        {
            var t1 = new TaskItem("Task 1", DateTime.Now, Priority.Low);
            var t2 = new TaskItem("Task 2", DateTime.Now, Priority.Low);
            Assert.NotEqual(t1.Id, t2.Id);
            Assert.Equal(t1.Id + 1, t2.Id);
        }

        [Fact]
        public void Edit_WithNulls_DoesNotChangeProperties()
        {
            var t = new TaskItem("Initial", DateTime.Now, Priority.Medium);
            var initialDescription = t.Description;
            var initialDeadline = t.Deadline;
            var initialPriority = t.Priority;
            t.EditTask(null, null, null);
            Assert.Equal(initialDescription, t.Description);
            Assert.Equal(initialDeadline, t.Deadline);
            Assert.Equal(initialPriority, t.Priority);
        }

        [Fact]
        public void Edit_WithEmptyDescription_DoesNotChangeDescription()
        {
            var t = new TaskItem("Initial", DateTime.Now, Priority.Medium);
            var initialDescription = t.Description;
            t.EditTask("", null, null);
            Assert.Equal(initialDescription, t.Description);
        }

        [Fact]
        public void Edit_WithDefaultDateTime_DoesNotChangeDeadline()
        {
            var t = new TaskItem("Initial", DateTime.Now, Priority.Medium);
            var initialDeadline = t.Deadline;
            t.EditTask(null, default(DateTime), null);
            Assert.Equal(initialDeadline, t.Deadline);
        }

        [Fact]
        public void ToString_ContainsIdAndDescription()
        {
            var t = new TaskItem("Sample Task", DateTime.Now, Priority.Low);
            var str = t.ToString();
            Assert.Contains(t.Id.ToString(), str);
            Assert.Contains("Sample Task", str);
        }

        [Fact]
        public void Creating_WithWhitespaceDescription_Throws()
        {
            Assert.Throws<ArgumentException>(() => new TaskItem("   ", DateTime.Now, Priority.Low));
        }

        [Fact]
        public void Creating_WithValidDescription_TrimsWhitespace()
        {
            var t = new TaskItem("  Trimmed  ", DateTime.Now, Priority.Low);
            Assert.Equal("Trimmed", t.Description);
        }

        [Fact]
        public void ToString_FormatsDeadlineCorrectly()
        {
            var deadline = new DateTime(2024, 12, 31);
            var t = new TaskItem("Year End Task", deadline, Priority.High);
            var str = t.ToString();
            Assert.Contains(deadline.ToString("ddd dd MMM yyyy"), str);
        }

        [Fact]
        public void MultipleTasks_HaveUniqueIds()
        {
            var tasks = new List<TaskItem>
            {
                new TaskItem("Task 1", DateTime.Now, Priority.Low),
                new TaskItem("Task 2", DateTime.Now, Priority.Medium),
                new TaskItem("Task 3", DateTime.Now, Priority.High)
            };
            var ids = tasks.Select(t => t.Id).ToList();
            Assert.Equal(ids.Count, ids.Distinct().Count());
        }

        [Fact]
        public void Edit_OnlyUpdatesSpecifiedFields()
        {
            var t = new TaskItem("Original", DateTime.Now, Priority.Low);
            var originalDeadline = t.Deadline;
            t.EditTask(newDescription: "Updated", newPriority: Priority.High);
            Assert.Equal("Updated", t.Description);
            Assert.Equal(Priority.High, t.Priority);
            Assert.Equal(originalDeadline, t.Deadline); // Deadline should remain unchanged
        }

        [Fact]
        public void MarkComplete_CanBeCalledMultipleTimes()
        {
            var t = new TaskItem("Repeat Complete", DateTime.Now, Priority.Medium);
            t.MarkComplete();
            Assert.True(t.IsCompleted);
            t.MarkComplete(); // Call again
            Assert.True(t.IsCompleted); // Should still be true
        }

        [Fact]
        public void ToString_DifferentPriorities_HaveCorrectLabels()
        {
            var low = new TaskItem("Low Priority", DateTime.Now, Priority.Low);
            var medium = new TaskItem("Medium Priority", DateTime.Now, Priority.Medium);
            var high = new TaskItem("High Priority", DateTime.Now, Priority.High);
            Assert.Contains("Low-priority", low.ToString());
            Assert.Contains("Medium-priority", medium.ToString());
            Assert.Contains("ALERT: High-priority", high.ToString());
        }

        [Fact]
        public void Edit_WithAllNulls_DoesNotThrow()
        {
            var t = new TaskItem("No Change", DateTime.Now, Priority.Low);
            var exception = Record.Exception(() => t.EditTask(null, null, null));
            Assert.Null(exception); // Should not throw any exception
        }

        [Fact]
        public void Edit_WithOnlyDeadline_UpdatesDeadline()
        {
            var t = new TaskItem("Change Deadline", DateTime.Now, Priority.Medium);
            var newDeadline = DateTime.Now.AddDays(5);
            t.EditTask(newDeadline: newDeadline);
            Assert.Equal(newDeadline, t.Deadline);
        }

        [Fact]
        public void ToString_IncludesAllDetails()
        {
            var deadline = new DateTime(2024, 6, 15);
            var t = new TaskItem("Complete Project", deadline, Priority.High);
            var str = t.ToString();
            Assert.Contains(t.Id.ToString(), str);
            Assert.Contains("Complete Project", str);
            Assert.Contains(deadline.ToString("ddd dd MMM yyyy"), str);
            Assert.Contains("High-priority", str);
            Assert.Contains("Not Completed", str);
        }


        [Fact]
        public void ToString_FormatsOutputCorrectly()
        {
            var deadline = new DateTime(2024, 6, 15);
            var t1 = new TaskItem("Complete Project", deadline, Priority.High);
            var t2 = new TaskItem("Complete Project", deadline, Priority.Medium);
            var t3 = new TaskItem("Complete Project", deadline, Priority.Low);

            var str1 = t1.ToString();
            var str2 = t2.ToString();
            var str3 = t3.ToString();

            Assert.Equal("1. ALERT: High-priority task: Complete Project by Sat 15 Jun 2024 - Not Completed", str1);
            Assert.Equal("2. Medium-priority task: Complete Project by Sat 15 Jun 2024 - Not Completed", str2);
            Assert.Equal("3. Low-priority task: Complete Project by Sat 15 Jun 2024 - Not Completed", str3);
        }

        [Fact]
        public void ToString_DoesNotThrow()
        {
            var t = new TaskItem("Safe ToString", DateTime.Now, Priority.Low);
            var exception = Record.Exception(() => t.ToString());
            Assert.Null(exception); // Should not throw any exception
        }

        [Fact]
        public void IsOverdue_ReturnsTrueForPastDeadlineAndNotCompleted()
        {
            var pastDate = DateTime.Today.AddDays(-1);
            var t = new TaskItem("Overdue Task", pastDate, Priority.Medium);
            Assert.True(t.IsOverdue());
            t.MarkComplete();
            Assert.False(t.IsOverdue()); // Should be false if completed
        }

    }
}
