﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Challenge5Tasky;
using Xunit;

namespace Challenge5Tests
{
    public class TaskManagerTests
    {
        [Fact]
        public void Add_IncreasesCountByOne()
        {
            var repo = new TaskManager();
            var before = repo.Tasks.Count;
            repo.Add("Task A", DateTime.Now, Priority.Medium);
            Assert.Equal(before + 1, repo.Tasks.Count);
        }

        [Fact]
        public void RemoveById_RemovesExistingTask()
        {
            var repo = new TaskManager();
            var t = repo.Add("Task B", DateTime.Now, Priority.Low);
            var removed = repo.Remove(t.Id);
            Assert.True(removed);
            Assert.DoesNotContain(repo.Tasks, x => x.Id == t.Id);
        }

        [Fact]
        public void RemoveById_NonExistent_ReturnsFalseAndNoChange()
        {
            var repo = new TaskManager();
            repo.Add("Task C", DateTime.Now, Priority.High);
            var before = repo.Tasks.Count;
            var removed = repo.Remove(9999);
            Assert.False(removed);
            Assert.Equal(before, repo.Tasks.Count);
        }

        //Create unit test for MarkComplete method to verify it marks the task as completed
        [Fact]
        public void MarkComplete_MarksTaskAsCompleted()
        {
            var repo = new TaskManager();
            var t = repo.Add("Task D", DateTime.Now, Priority.Medium);
            Assert.False(t.IsCompleted);
            var marked = repo.MarkComplete(t.Id);
            Assert.True(marked);
            Assert.True(t.IsCompleted);
        }

        //Create unit test to verify SortedByPriorityDesc returns tasks in correct order    
        [Fact]
        public void SortedByPriorityDesc_ReturnsTasksInCorrectOrder()
        {
            var repo = new TaskManager();
            var t1 = repo.Add("Task Low", DateTime.Now, Priority.Low);
            var t2 = repo.Add("Task High", DateTime.Now, Priority.High);
            var t3 = repo.Add("Task Medium", DateTime.Now, Priority.Medium);
            var sorted = repo.SortedByPriorityDesc().ToList();
            Assert.Equal(3, sorted.Count);
            Assert.Equal(t2.Id, sorted[0].Id); // High priority first
            Assert.Equal(t3.Id, sorted[1].Id); // Medium priority second
            Assert.Equal(t1.Id, sorted[2].Id); // Low priority last
        }
    }
}
