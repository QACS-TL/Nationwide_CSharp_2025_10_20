﻿
// Program.cs (Console App) — Challenge 2
using Challenge4;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;

var manager = new TaskManager();

void ShowMenu()
{
    Console.WriteLine();
    Console.WriteLine("== To-Do List Manager ==");
    Console.WriteLine("[1] Add task");
    Console.WriteLine("[2] View tasks");
    Console.WriteLine("[3] Mark complete");
    Console.WriteLine("[4] Remove task");
    Console.WriteLine("[5] Edit task");
    Console.WriteLine("[6] View tasks (sorted by priority)");
    Console.WriteLine("[0] Exit");
    Console.Write("Select: ");
}

string PromptAndRead(string prompt)
{
    Console.Write(prompt);
    return (Console.ReadLine() ?? "").Trim();
}

string ReadNonEmpty(string prompt)
{
    while (true)
    {
        var input = PromptAndRead(prompt);
        if (!string.IsNullOrWhiteSpace(input))
            return input;
        Console.WriteLine("Input cannot be empty.");
    }
}

DateTime ReadValidDeadline(string prompt)
{
    while (true)
    {
        var input = PromptAndRead(prompt);
        if (string.IsNullOrWhiteSpace(input))
            return DateTime.Today;
        if (DateTime.TryParse(input, out var deadline))
        {
            if (deadline >= DateTime.Today)
                return deadline;
            Console.WriteLine("Deadline cannot be in the past.");
        }
        else
        {
            Console.WriteLine("Please enter a valid date.");
        }
    }
}

Priority ReadPriority()
{
    while (true)
    {
        var s = PromptAndRead("Priority (Low/Medium/High): ").ToLowerInvariant();
        if (s is "low" or "l") return Priority.Low;
        if (s is "medium" or "m") return Priority.Medium;
        if (s is "high" or "h") return Priority.High;
        Console.WriteLine("Invalid priority.");
    }
}

int? SelectTaskIndex(string prompt)
{
    ViewTasks();
    Console.Write(prompt);
    if (int.TryParse(Console.ReadLine(), out var n) && n >= 1 && n <= manager.Tasks.Count)
        return n - 1;
    Console.WriteLine("Invalid selection.");
    return null;
}

void AddTask()
{
    string description = ReadNonEmpty("Description: ");
    DateTime deadline = ReadValidDeadline("Deadline (e.g. 31/12/2026) assumes today if left blank: ");
    Priority priority = ReadPriority();

    manager.Add(description, deadline, priority);
    Console.WriteLine("Added.");
}

void ViewTasks(bool sort = false)
{
    if (manager.Tasks.Count == 0)
    {
        Console.WriteLine("(No tasks)");
        return;
    }
    if (sort)
    {
        Console.WriteLine("Tasks (sorted by priority):");
        foreach (var t in manager.SortedByPriorityDesc())
        {
            Console.WriteLine($"{t}");
        }
        return;
    }

    foreach (var t in manager.Tasks)
    {
        Console.WriteLine($"{t}");
    }
}

void RemoveTask()
{
    if (manager.Tasks.Count == 0)
    {
        Console.WriteLine("No tasks to remove.");
        return;
    }
    var idx = SelectTaskIndex("Remove which number? ");
    if (idx.HasValue)
    {
        manager.Remove(idx.Value + 1);
        Console.WriteLine("Removed.");
    }
}

void EditTask()
{
    if (manager.Tasks.Count == 0)
    {
        Console.WriteLine("No tasks to edit.");
        return;
    }
    var idx = SelectTaskIndex("Edit which number? ");
    if (idx.HasValue)
    {
        string description = PromptAndRead("Description, leave blank if no update required: ");
        DateTime deadline = default(DateTime);
        Priority? priority = null;
        while (true)
        {
            var input = PromptAndRead("Deadline (e.g. 31/12/2026) leave blank if no update required:: ");
            if (string.IsNullOrWhiteSpace(input))
                break;
            if (DateTime.TryParse(input, out deadline))
            {
                if (deadline >= DateTime.Today)
                    break;
                Console.WriteLine("Deadline cannot be in the past.");
            }
            else
            {
                Console.WriteLine("Please enter a valid date.");
            }
        }
        priority = ReadPriority();
        manager.Edit(idx.Value + 1, description, deadline, priority);
        Console.WriteLine("Edited.");
    }
}

void MarkComplete()
{
    if (manager.Tasks.Count == 0)
    {
        Console.WriteLine("No tasks to mark as complete.");
        return;
    }
    var idx = SelectTaskIndex("Mark which number as complete? ");
    if (idx.HasValue)
    {
        manager.Tasks[idx.Value].MarkComplete();
    }
}

// --- Main flow ---
Console.WriteLine("== Task Prioritizer ==");
// Load TaskItems from file
if (!System.IO.File.Exists("tasks.txt"))
{
    using (var stream = System.IO.File.Create("tasks.txt")) { }
}

List<string> tasks = System.IO.File.ReadAllLines("tasks.txt").ToList<String>(); 
{
    foreach (var taskAsJson in tasks)
    {
        TaskItem task = JsonConvert.DeserializeObject<TaskItem>(taskAsJson);
        manager.Add(task.Description, task.Deadline, task.Priority);
    }
}

while (true)
{
    ShowMenu();
    var choice = Console.ReadLine();
    Console.WriteLine();

    switch (choice)
    {
        case "1": AddTask(); break;
        case "2": ViewTasks(); break;
        case "3": MarkComplete(); break;
        case "4": RemoveTask(); break;
        case "5": EditTask(); break;
        case "6": ViewTasks(true); break;
        case "0": Console.WriteLine("Goodbye!"); break;
        default: Console.WriteLine("Unknown option."); break;
    }
    if (choice == "0") break;
}
//Persist TaskItems to file
using (StreamWriter writer = System.IO.File.AppendText("tasks.txt"))
{
    foreach (var task in manager.Tasks)
    {
        string taskAsJson = JsonConvert.SerializeObject(task);
        writer.WriteLine(taskAsJson);
    }
}
