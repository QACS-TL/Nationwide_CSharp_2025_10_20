﻿// Program.cs (Console App) — Challenge 1
using System;

string CreateTaskString(string description, DateTime deadline)
    => $"Task: {description} by {deadline:ddd dd MMM yyyy}";

void PrintTask(string task)
    => Console.WriteLine(task);

string ReadNonEmpty(string prompt)
{
    while (true)
    {
        Console.Write(prompt);
        var input = Console.ReadLine() ?? "";
        if (!string.IsNullOrWhiteSpace(input))
            return input.Trim();
        Console.WriteLine("Please enter a non-empty value.");
    }
}

// --- Main flow ---
Console.WriteLine("== Task Creator ==");
var description = ReadNonEmpty("Description: ");
var deadline = DateTime.Parse(ReadNonEmpty("Deadline: "));

var task = CreateTaskString(description, deadline);
PrintTask(task);

// (Optional extension from the brief)
bool completed = false;
Console.Write("Mark as completed? (y/n): ");
if ((Console.ReadLine() ?? "").Trim().Equals("y", StringComparison.OrdinalIgnoreCase))
{
    completed = true;
}
if (completed) task += " - Completed";
PrintTask(task);
