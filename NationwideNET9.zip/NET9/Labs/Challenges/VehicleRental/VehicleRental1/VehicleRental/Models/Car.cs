﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleRental.Models
{
    public class Car : Vehicle
    {
        public int NumberOfDoors { get; set; }

        public override void Rent()
        {
            IsRented = true;
        }

        public override void Return()
        {
            IsRented = false;
        }

        public override string ToString()
        {
            return base.ToString() + $" and has {NumberOfDoors} doors";
        }
    }
}
