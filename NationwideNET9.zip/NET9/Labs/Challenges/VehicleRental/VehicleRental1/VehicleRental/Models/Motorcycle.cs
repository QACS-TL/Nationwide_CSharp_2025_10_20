﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleRental.Models
{
    public class Motorcycle : Vehicle
    {
        public bool HasSidecar { get; set; }

        public override void Rent()
        {
            IsRented = true;
        }

        public override void Return()
        {
            IsRented = false;
        }

        public override string ToString()
        {
            return base.ToString() + $" and {(HasSidecar ? "has": "does not have")} a side car";
        }
    }
}
