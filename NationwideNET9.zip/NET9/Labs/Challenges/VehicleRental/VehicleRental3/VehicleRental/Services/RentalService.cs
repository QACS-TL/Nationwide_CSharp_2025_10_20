﻿using Microsoft.EntityFrameworkCore;
using VehicleRental.Models;
namespace VehicleRental.Services
{
    public class RentalService
    {
        private List<Vehicle> _vehicles { get; set; }

        public RentalService(List<Vehicle> vehicles) => _vehicles = vehicles;

        // Collections: materialize to List for in-memory operations if needed
        public List<Vehicle> GetAll()
        {
            var cars = _vehicles.Where(v => v is Car).ToList<Vehicle>();
            var motos = _vehicles.Where(v => v is Motorcycle).ToList<Vehicle>();
            return cars.Concat(motos).OrderBy(v => v.Id).ToList();
        }

        public List<Vehicle> GetAvailable() =>
             GetAll().Where(v => !v.IsRented).ToList();

        public List<Vehicle> GetRented() =>
             GetAll().Where(v => v.IsRented).ToList();

        // LINQ filter by price
        public List<Vehicle> FindUnderDailyRate(decimal maxRate) =>
            GetAll().Where(v => v.DailyRate <= maxRate && !v.IsRented).ToList();

        public void Rent(int id)
        {
            var vehicle = FindTracked(id)
                ?? throw new VehicleNotAvailableException($"Vehicle with id {id} was not found.");

            try
            {
                vehicle.Rent(); // may throw Exception
            }
            catch (DbUpdateException ex)
            {
                throw new InvalidOperationException("Database error while returning.", ex);
            }
        }

        public Vehicle Return(int id)
        {
            var vehicle = FindTracked(id)
                ?? throw new VehicleNotAvailableException($"Vehicle with id {id} was not found.");

            try
            {   
                vehicle.Return();
                return vehicle;
            }
            catch (DbUpdateException ex)
            {
                throw new InvalidOperationException("Database error while returning.", ex);
            }

        }

        private Vehicle? FindTracked(int id)
        {
            // Try cars first, then motorcycles
            var car = _vehicles.Where(v => v is Car).FirstOrDefault(c => c.Id == id);
            if (car is not null) return car;

            var moto = _vehicles.Where(v => v is Motorcycle).FirstOrDefault(m => m.Id == id);
            return moto;

        }
    }
}
