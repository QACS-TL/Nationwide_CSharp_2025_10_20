﻿using Microsoft.EntityFrameworkCore;
using VehicleRental.Models;
using VehicleRental.Services;
using Xunit;

namespace VehicleRentalTests
{

    public class RentalServiceTests
    {
        private List<Vehicle> vehicles = new List<Vehicle>();

        public RentalServiceTests()
        {
            vehicles.AddRange(
                new Car { Id = 1, Model = "Toyota Corolla T", DailyRate = 40m, NumberOfDoors = 4, IsRented = false },
                new Car { Id = 2, Model = "Tesla Model 3 T", DailyRate = 85m, NumberOfDoors = 4, IsRented = false },
                new Motorcycle { Id = 3, Model = "Harley Davidson T", DailyRate = 55m, HasSidecar = false, IsRented = false },
                new Motorcycle { Id = 4, Model = "Honda Gold Wing T", DailyRate = 70m, HasSidecar = true, IsRented = true }
            );
        }

        [Fact]
        public void Rent_Vehicle_ShouldMarkAsRented()
        {
            var service = new RentalService(vehicles);

            service.Rent(1);

            Vehicle car = service.Return(1);
            Assert.True(!car.IsRented);
        }

        [Fact]
        public void Rent_AlreadyRented_ShouldThrow()
        {
            var service = new RentalService(vehicles);

            Assert.Throws<VehicleNotAvailableException>(() => service.Rent(5));
        }

        [Fact]
        public void Return_Vehicle_ShouldMarkAsAvailable()
        {
            var service = new RentalService(vehicles);

            service.Return(4);

            var moto = service.Return(4);
            Assert.False(moto!.IsRented);
        }

        [Fact]
        public void FindUnderDailyRate_FiltersAndOnlyAvailable()
        {
            var service = new RentalService(vehicles);

            var results = service.FindUnderDailyRate(60m);

            Assert.All(results, v => Assert.True(v.DailyRate <= 60m && !v.IsRented));
            Assert.Contains(results, v => v.Model == "Toyota Corolla T");
            Assert.DoesNotContain(results, v => v.Model == "Honda Gold Wing T"); // rented
        }
    }
}
