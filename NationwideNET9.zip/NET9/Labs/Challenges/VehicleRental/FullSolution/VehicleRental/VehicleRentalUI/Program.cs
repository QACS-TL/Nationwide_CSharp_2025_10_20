﻿using Microsoft.EntityFrameworkCore;
using VehicleRental.Models;
using VehicleRental.Services;

Console.WriteLine("Welcome to Vehicle Rental System!");

using var db = new RentalDbContext();
// Ensure database & seed data
//if (db.Database.EnsureCreated())
//    db.Database.Migrate();

db.Database.EnsureCreated();
var service = new RentalService(db);

bool exit = false;

while (!exit)
{
    Console.WriteLine(@"
        1. View all vehicles
        2. View available vehicles
        3. Rent a vehicle
        4. Return a vehicle
        5. Search vehicles under price
        6. View rented vehicles
        7. Exit");

    Console.Write("> ");
    var input = Console.ReadLine();

    if (string.IsNullOrWhiteSpace(input))
    {
        Console.WriteLine("Please enter a choice.");
        continue;
    }

    if (!int.TryParse(input, out var choice))
    {
        Console.WriteLine("Invalid input. Enter a number.");
        continue;
    }

    try
    {
        if (choice == 1)
        {
            var all = service.GetAll();
            Print(all);
        }
        else if (choice == 2)
        {
            var available = service.GetAvailable();
            Print(available);
        }
        else if (choice == 3)
        {
            Console.Write("Enter vehicle ID to rent: ");
            if (int.TryParse(Console.ReadLine(), out var id))
            {
                service.Rent(id);
                Console.WriteLine("Vehicle rented successfully.");
            }
            else
            {
                Console.WriteLine("Invalid ID.");
            }
        }
        else if (choice == 4)
        {
            Console.Write("Enter vehicle ID to return: ");
            if (int.TryParse(Console.ReadLine(), out var id))
            {
                service.Return(id);
                Console.WriteLine("Vehicle returned successfully.");
            }
            else
            {
                Console.WriteLine("Invalid ID.");
            }
        }
        else if (choice == 5)
        {
            Console.Write("Enter max daily rate: ");
            if (decimal.TryParse(Console.ReadLine(), out var max))
            {
                var results = service.FindUnderDailyRate(max);
                Print(results);
            }
            else
            {
                Console.WriteLine("Invalid price.");
            }
        }
        else if (choice == 6)
        {
            var rented = service.GetRented();
            Print(rented);
        }
        else if (choice == 7)
        {
            exit = true;
        }
        else
        {
            Console.WriteLine("Unknown option. Try again.");
        }
    }
    catch (VehicleRental.Models.VehicleNotAvailableException vex)
    {
        Console.WriteLine($"Error: {vex.Message}");
    }
    catch (ArgumentException aex)
    {
        Console.WriteLine($"Error: {aex.Message}");
    }
    catch (InvalidOperationException ioex)
    {
        Console.WriteLine($"Unexpected database error: {ioex.Message}");
    }
    catch (Exception ex)
    {
        Console.WriteLine($"Unexpected error: {ex.Message}");
    }
}

static void Print(IEnumerable<VehicleRental.Models.Vehicle> vehicles)
{
    var list = vehicles.ToList();
    if (!list.Any())
    {
        Console.WriteLine("(no vehicles)");
        return;
    }

    foreach (var v in list)
    {
        Console.WriteLine($"{v.Id}. {v}");
    }
}

Console.WriteLine("Goodbye!");