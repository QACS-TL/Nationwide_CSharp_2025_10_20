﻿using Microsoft.EntityFrameworkCore;
using VehicleRental.Models;
namespace VehicleRental.Services
{
    public class RentalService
    {
        private readonly RentalDbContext _db;

        public RentalService(RentalDbContext db) => _db = db;

        // Collections: materialize to List for in-memory operations if needed
        public List<Vehicle> GetAll()
        {
            var cars =  _db.Cars.AsNoTracking().ToList<Vehicle>();
            var motos =  _db.Motorcycles.AsNoTracking().ToList<Vehicle>();
            return cars.Concat(motos).OrderBy(v => v.Id).ToList();
        }

        public List<Vehicle> GetAvailable() =>
             GetAll().Where(v => !v.IsRented).ToList();

        public  List<Vehicle> GetRented() =>
             GetAll().Where(v => v.IsRented).ToList();

        // LINQ filter by price
        public List<Vehicle> FindUnderDailyRate(decimal maxRate) =>
            GetAll().Where(v => v.DailyRate <= maxRate && !v.IsRented).ToList();

        public void Rent(int id)
        {
            var vehicle =  FindTracked(id)
                ?? throw new VehicleNotAvailableException($"Vehicle with id {id} was not found.");

            try
            {
                vehicle.Rent(); // may throw VehicleNotAvailableException
                _db.SaveChangesAsync();
            }
            catch (DbUpdateException ex)
            {
                throw new InvalidOperationException("Database error while renting.", ex);
            }
        }

        public  void Return(int id)
        {
            var vehicle =  FindTracked(id)
                ?? throw new VehicleNotAvailableException($"Vehicle with id {id} was not found.");

            try
            {
                vehicle.Return();
                _db.SaveChanges();
            }
            catch (DbUpdateException ex)
            {
                throw new InvalidOperationException("Database error while returning.", ex);
            }
        }

        private Vehicle? FindTracked(int id)
        {
            // Try cars first, then motorcycles
            var car = _db.Cars.FirstOrDefault(c => c.Id == id);
            if (car is not null) return car;

            var moto = _db.Motorcycles.FirstOrDefault(m => m.Id == id);
            return moto;
        }
    }
}
