﻿AverageCalculator calculator = new AverageCalculator();

calculator.AveragesWithWhile();
Console.WriteLine("==========");
calculator.AveragesWithDoWhile();
Console.WriteLine("==========");
calculator.AveragesWithFor();

