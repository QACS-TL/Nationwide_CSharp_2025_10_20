﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DoingLunch
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("What main dish would you like?");

            //Console.WriteLine("How many roast potatoes?");

            //Console.WriteLine("How many brussel sprouts?");


            // Put the display here!

        }

    }
}