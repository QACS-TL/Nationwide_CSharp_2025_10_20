using Conditionals;

namespace IfYouHaveTimeTests
{
    public class PolarTests
    {
        [Fact]
        public void NorthPoleTest()
        {
            //Arrange
            Pole pole = Pole.North;
            string animal;
            string expectedAnimal = "Polar Bear";

            //Act
            animal = Program.GetArcticAnimal(pole);

            //Assert
            Assert.Equal(expectedAnimal, animal);
        }

        [Fact]
        public void SouthPoleTest()
        {
            //Arrange
            Pole pole = Pole.South;
            string animal;
            string expectedAnimal = "Penguin";

            //Act
            animal = Program.GetArcticAnimal(pole);

            //Assert
            Assert.Equal(expectedAnimal, animal);
        }
    }
}