﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceAndAbstractClasses
{
    internal class Triangle: Polygon
    {
        public Triangle()
        {
            NumberOfSides = 3;
        }
    }
}
