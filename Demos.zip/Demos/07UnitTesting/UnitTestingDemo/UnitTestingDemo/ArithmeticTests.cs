using ProjectUnderTest;

namespace UnitTestingDemo
{
    public class ArithmeticTests
    {
        [Fact]
        public void MultiplyTest()
        {
            //Arrage
            int initialValue = 5;
            long expectedResult = 120;
            long actualResult = 0;

            //Act
            actualResult = Arithmetic.GenerateFactorial(initialValue);

            //Assert
            Assert.Equal(expectedResult, actualResult);
        }
    }
}